 # Sorts a sequence in ascending order using the bubble sort algorithm.
def bubbleSort( theSeq ):
    n = len( theSeq )
    # Perform n-1 bubble operations on the sequence
    for i in range( n - 1 ):
        print("array before ", i, "run: ", a)
        # Bubble the largest item to the end.
        for j in range( i,  n - 1 ) :
            if theSeq[j] > theSeq[j + 1] :
                # swap the j and j+1 items.
                print("swap ",theSeq[j], " with ", theSeq[j + 1]  )
                tmp = theSeq[j]
                theSeq[j] = theSeq[j + 1]
                theSeq[j + 1] = tmp


#test
a = [2,3,5,8,7]

print("before sorting ", a)
bubbleSort(a)
print("after sorting ", a)


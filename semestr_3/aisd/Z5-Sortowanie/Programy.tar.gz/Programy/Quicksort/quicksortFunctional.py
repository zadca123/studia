#!/usr/bin/env python2
# -*- coding: utf-8 -*-


def qsort(arr): 
    if len(arr) <= 1:
        return arr
    else:
        return qsort([x for x in arr[1:] if x < arr[0]]) + \
               [arr[0]] + \
               qsort([x for x in arr[1:] if x >= arr[0]])
               
               
a = [3,4,1,2]
print("before sort=", a)
a=qsort(a)
print("after sort=", a)
#include <iostream>
#include <string>
using namespace std;

int hash( const string &key, int max) 
{
   int hashVal = 0;

   for(int i = 0; i<key.length();  i++)
   {
      hashVal += key[i];
	}
   hashVal %= max;
   return hashVal;
}

int main()
{
  string s("HelloWorld");
  cout << hash( s, 7) << endl;
  return 0;
}

